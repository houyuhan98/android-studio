//
// Created by Y YM on 2018/10/19.
//

#include <jni.h>
#include <string>
#include "displayfile.h"

extern "C"


//JNIEXPORT jstring JNICALL Java_edu_ufl_cise_os_p2_P2Activity_stringFromJNI(
//        JNIEnv *env,
//        jobject /* this */) {
//    std::string hello = "Hello from C++";
//    return env->NewStringUTF(hello.c_str());
//}

JNIEXPORT jstring JNICALL Java_edu_ufl_cise_os_p2_P2Activity_readFile
        (JNIEnv *env, jobject /* this */, jstring jstr) {
    const char *str = env->GetStringUTFChars(jstr, NULL);
    FILE *fp = fopen(str, "r");
    env->DeleteLocalRef(jstr);
    if (fp) {
        // read the whole length of file
        fseek(fp, 0, SEEK_END);
        long len = ftell(fp);
        // reset position
        rewind(fp);
        char *file_buffer = (char *) malloc(len + 1);

        if (!file_buffer) {
            return NULL;
        }
        fread(file_buffer, 1, len, fp);
        fclose(fp);
        // convert char* to const char*
        file_buffer[len] = 0;
        std::string str(file_buffer);
        free(file_buffer);
        // @link https://stackoverflow.com/questions/12127817/android-ics-4-0-ndk-newstringutf-is-crashing-down-the-app
        jbyteArray array = env->NewByteArray(str.size());
        env->SetByteArrayRegion(array, 0, str.size(), (const jbyte *) str.c_str());
        jstring strEncode = env->NewStringUTF("UTF-8");
        jclass cls = env->FindClass("java/lang/String");
        jmethodID ctor = env->GetMethodID(cls, "<init>", "([BLjava/lang/String;)V");
        jstring object = (jstring) env->NewObject(cls, ctor, array, strEncode);
        env->DeleteLocalRef(strEncode);
        env->DeleteLocalRef(array);
        return object;
    }
    return NULL;
}